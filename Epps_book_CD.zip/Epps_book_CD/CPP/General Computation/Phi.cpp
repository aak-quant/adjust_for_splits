#include <math.h>
#include <iostream.h>


double phi(float x)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Evaluate Standard Normal CDF
*     Input:     x
*     Output:    Phi(x)= Pr(Z<x), where Z ~N(0,1)
*     Reference: Moran, P.A.P. (1980), "Calculation of the normal
*                distribution function", Biometrika 67 (3), 675-676.
*     Notes:     Accuracy to 7 decimal places when |x|< 5.
*     Required
*     routines:  None
*----------------------------------------------------------------------
*/


    static double rt2by3 = 0.471404520791032, 
                  threert2 = 4.24264068711929,
                  pi = 3.14159265358979;
    
    double return_value = 0.5;

    if(x == 0.0) 
        return return_value;
    
    double dphi=x/threert2;
    
    for (int j=1; j <= 12; j++) 
    {
        dphi=dphi+exp(-(j*j/9.0))*sin(j*x*rt2by3)/j;
    }
    
    return_value=0.5+dphi/pi;


    return return_value;
}



