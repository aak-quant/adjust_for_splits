#include <complex.h>
#include <fstream.h>

#include <math.h>

#include <nan.h>


complex psi1(float t, float &center, float &scale);
complex psi2(float t, float &center, float &scale);
void four1(float fft[],unsigned long n,int);

void invfFt(const int n, float t[], float CDF[])
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Apply the fast Fourier transform to invert the c.f.
*                corresponding to an absolutely-continuous c.d.f. F,
*                and thereby to recover values of F(t) on a grid of
*                points {t}.
*     Input:     Number of points at which F is evaluated, n
*     Output:    Values of c.d.f. at points {t), CDF
*     Reference: Press, W. et al (1992) Numerical Recipes in FORTRAN,
*                Cambridge Press.
*     Required routines:
*                (1) User-supplied complex-valued function PSI that
*                calculates from the parameters a 'center' and a
*                'scale,' then calculates 1/(i*t) times the c.f. of
*                the centered and scaled r.v. whose distribution is F.
*                (2) From Numerical Recipes, Press et. al.(1992), FOUR1
*     Notes:     (1) n must be a power of 2 no larger than 2**14,
*                    depending on available memory. Larger n => greater
*                    range of values where F is evaluated & better
*                    accuracy in the tails, but slower execution.
*                (2) Choice of center and scale is not crucial if most
*                    probability mass is between -10 and +10 after
*                    centering and scaling.  Original center and scale
*                    is restored at output.
*                (3) Two example psi functions, PSI1 and PSI2, are
*                    provided. To run one, change the name to PSI.
*                (4) Set options in ***Set options*** block to control
*                    printing and domain on which F is calculated.
*----------------------------------------------------------------------
*/
    const char printit = 'y';
    const char *outfile = "yourfile";
/*
***************** Set options *****************************************
*     Set print options: printit='y' or 'n', & outfile="file name"
*     Set computation options:
*     nt controls spacing of {t} for F(t): t(j)-t(j-1)=1/(2*nt).
*        Larger nt => denser {t} but lower accuracy in the tails for
*        given value of n.
*        Set tmin>-1000, tmax<+1000 to restrict computation of F to
*        domain [tmin,tmax].  Set tmin >=0 if F(0-)=0.
***********************************************************************
*/
    const int nt=10;
    float tmin=-4,tmax=4;
    
    float fft[2*16384+1];

    static complex i(0.0, 1.0);
    int j;
    
    ofstream fout;

    if(printit == 'y') {
        fout.open(outfile);
        fout << "        t         F(t)";
    }

//*
    float twopi=2*acos(-1.0);
    float ttop=nt*twopi;
    float del=2*ttop/n;
    float t0=-ttop-del/2;
    float delby2pi=del/twopi;
    
    for (j=1; j <= n/2; j++) 
    {
        t[j]=t0+j*del;
        t[n+1-j]=-t[j];
    }

    float c, s;
    for (j=1; j <= n; j++) 
    {
        fft[2*j-1]=real((psi2(t[j],c,s)+psi2(-t[j],c,s))/2);
        fft[2*j]  =real((psi2(t[j],c,s)-psi2(-t[j],c,s))/(2*i));
    }
    
    four1(fft,n,-1);


    t0=twopi/(n*del);
    
    int kntt=0;
    
    float tt, signj;

    for (j=n/2+1; j <= n; j++) 
    {
        tt=-t0*(n-j+1)*s+c;
        if(tt < tmin) 
            goto label_1;
        
        kntt=kntt+1;
        signj=pow((-1),(j-1));
        t[kntt]=tt;
        CDF[kntt]=0.5-signj*fft[2*j-1]*delby2pi;
        if (printit == 'y')
            fout << t[kntt] << " " << CDF[kntt] << endl;
label_1:
        ;
    }
    
    for (j=1; j <= n/2; j++) 
    {
        tt=t0*(j-1)*s+c;
        if(tt > tmax) 
            return;
        kntt=kntt+1;
        signj=pow((-1),(j-1));
        t[kntt]=tt;
        CDF[kntt]=0.5-signj*fft[2*j-1]*delby2pi;
        if (printit == 'y')
            fout << t[kntt] << " " << CDF[kntt] << endl;
label_2:
         ;
    }

    return;
}


complex myexp(complex c) 
{
    if (real(c) < -700 && (imag(c) == 0.0 || imag(c) == -0.0))
        return complex(0.0, 0.0);
    else
        return exp(c);
}


//*     Example 1: centered, scaled gamma(alpha,1)

complex psi1(float t, float &center, float &scale) 
{
    complex psi1;
    static complex i(9.0, 1.0);
    static float alpha = 1.0;
    scale=sqrt(alpha);
    center=alpha;
    float tt=t/scale;
    
    return ( myexp(-i*tt*center)*pow((1.-i*tt),(-alpha)) )/(i*t);
}


//*     Example 2: standard normal, not quite centered

complex psi2(float t, float &center, float &scale)
{
    complex psi2;
    static complex i(0.0, 1.0);
    static float rmu = 0.0, sig = 1.0;
    
    scale=.5;
    center=-.5;
    float tt=t/scale;

    return myexp(-i*tt*center)*myexp(i*rmu*tt-((sig*tt)*(sig*tt))/2.)
                /(i*t); 
}


