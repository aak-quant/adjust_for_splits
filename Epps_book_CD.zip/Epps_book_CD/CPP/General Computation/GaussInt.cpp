#include <iostream.h>
#include <math.h>


inline float max(float a, float b) 
{
    return (a > b) ? a : b;
}

float n(float x) 
{
    return exp(-x*x/2); 
}


float gaussint(float (*f)(float), float a, float b, float dz)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Integrate function f(z) between a and b with respect
*                to std. normal density by rectangular approximation
*                on grid spaced 'dz'.
*     Input:     Integration limits, a and b
*                Grid spacing, dz
*     Output:    Integral between a and b of product of f(z) and
*                standard normal p.d.f.
*     Notes:
*       (1)  'dz' must be specified; a suggested value is .001.
*       (2)  For a=-inf and/or b=+inf, set a=-1000. and/or b=+1000.
*       (3)  'f' must appear in EXTERNAL statement in main program.
*     Required routines:  User-supplied function f(z)
*----------------------------------------------------------------------
*/

    const float zero=0.0, one=1.0, inf=1000.0;
    const int maxloop=50000;
    const float tol=1.0e-10;
    
    float return_value = zero;
    
    
    if (a == b)
    {
        return return_value;
    }
    else if(a > b) 
    {
        cout << " GaussInt fails: <a> must be less than <b>! " << endl;
        return return_value;
    }

    float z, p, delta;
    int loop=0;

    if(a < zero && b > zero) 
    {
        z=zero;
        return_value=f(z);
label_1:
        loop=loop+1;
        if (loop > maxloop) 
            goto label_4;
        z=z+dz;
        p=n(z);
        delta=zero;
        if(a <= -z) 
            delta=delta+p*f(-z);
        if(b >=  z) 
            delta=delta+p*f(z);
        return_value=return_value+delta;

        if (fabs(delta) >= tol || fabs(z) < 4.) 
            goto label_1;
        if (max(-a,b) < inf && fabs(z) < max(-a,b)) 
            goto label_1;
        return_value=dz*return_value/sqrt(2.*acos(-one));
        return return_value;
    }
    else if (a < zero && b <= zero) 
    {
        z=b+dz/2;
label_2:
        loop=loop+1;
        if (loop > maxloop) 
            goto label_4;
        z=z-dz;
        delta=zero;
        if (z >= a-dz/2) 
            delta=n(z)*f(z);
        return_value=return_value+delta;
        if (fabs(delta) >= tol || z > -4.0) 
            goto label_2;
        if (a > -inf && z > a) 
            goto label_2;
        return_value=dz*return_value/sqrt(2.0*acos(-one));
        return return_value;
    }
    else if (a >= zero && b >= zero) 
    {
        z=a-dz/2;
label_3:
        loop=loop+1;
        if (loop > maxloop) 
            goto label_4;
        z=z+dz;
        delta=zero;
        if (z <= b+dz/2) 
            delta=n(z)*f(z);
        return_value=return_value+delta;
        if (fabs(delta) >= tol || z < 4.0) 
            goto label_3;
        if (b < inf && z < b) 
            goto label_3;
        return_value=dz*return_value/sqrt(2.0*acos(-one));
        return return_value;
    }
label_4:
    cout << " GaussInt fails: Iteration limit surpassed! " << endl;
    return return_value;
}



