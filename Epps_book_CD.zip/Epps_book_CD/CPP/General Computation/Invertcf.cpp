#include <iostream.h>
#include <complex.h>

#include <math.h>



void CF(complex *phi, double h, int N);
double F(double x, int N, double h, complex *phi);


void INVERTCF(double x[], int nx, double Fx[], int N, double h,
              complex *phi)
{
/*
*----------------------------------------------------------------------
*     Purpose:   Evaluate c.d.f. F(x) at nx points {x} by Fourier
*                inversion of c.f.
*     Input:     Array of points, x
*                Length of array, nx
*                Length of grid at which c.f. is evaluated, N
*                Spacing of grid for c.f., h
*     Output:    Array of c.d.f. values, Fx
*     Reference: Waller, L et al. (1985) Amer. Statist. 49(4), 346-350.
*     Notes: (1) Random variable whose c.f. is inverted should be
*                roughly centered and with unit scale; e.g., in standard
*                form.
*            (2) N and h correspond to H and eta in Waller et al. and
*                control the grid on which c.f. is evaluated.  Reducing
*                h with N fixed makes the grid denser, sharpening
*                estimates of tail probabilities, but shrinks the range,
*                [-Nh,Nh]. Increasing N with h fixed extends the range
*                and improves accuracy near mode.
*     Required routines:
*                User-supplied subroutine PHI to calculate the c.f. of
*                a standardized r.v. Example routine supplied.
*----------------------------------------------------------------------
*/

    CF(phi,h,N);
    for (int ix=1; ix <= nx; ix++)
        Fx[ix]=F(x[ix],N,h,phi);
    return;
}

double F(double x, int N, double h, complex *phi)
{
//*     Fourier inversion of phi, as per Eq.(1) in Waller et al.

    complex ij, ijhx;
    static complex i(0.0, 1.0);

    double pi2=2.0*acos(-1.0);
    double hx=h*x;
    double return_value=0.5 + hx/pi2;
    
    for (int j = 1; j <= N-1; j++) 
    {
        ij=i*j;
        ijhx=ij*hx;
        return_value=return_value-real(( phi[j]*exp(-ijhx)-phi[-j]
        *exp(ijhx) )/(pi2*ij));
    }
    return return_value;
}


//*     Examples of CF routines
//*

void CF(complex *phi, double h, int N)
{
//*     Calulate the c.f. on a grid spaced h.
    static complex i(0.0,1.0);
    
    for (int j=1-N; j <= N-1; j++) 
    {
/*
*        Standard Cauchy:
*           phi(j)=exp(-abs(j*h));
*        Standard normal:
*/
        phi[j]=exp(-.5*((j*h)*(j*h)));  
/*
*        Chi-square(2) in standard form:
*           phi(j)=exp(-i*j*h)*1.0/(1.0-i*j*h);
*        Chi-square(5) in standard form:
*           phi(j)=exp(-i*j*h*5.0/sqrt(10.0))*1.0/
                   pow((1.0-2.0*i*j*h/sqrt(10.0)),2.5);
*/
    }
}




