#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>

#include <string.h>
#include <math.h>
#include <stdlib.h>


inline int max(int a, int b) 
{
    return (a > b) ? a : b;
}


float gammQ(float a, float x);
float gammln(float xx);
double phi(float x);
void B_S(float SS, float X, float sigma, float B, float T, 
         const char *underlying,float div, const char *option,
         float &optval);


float gampdf(float x, float a);
void cev();

int main()
{
    cev();
    return 0;
}

void cev()
{
/*    
*----------------------------------------------------------------------
*   Purpose:   Values European puts and calls on underlying asset that
*              follows c.e.v. dynamics and pays continuous dividend.
*   Inputs:    Called for at execution
*   Output:    Values of puts and calls under c.e.v. dynamics, Black-
*              Scholes values at same initial volatility, and
*              differences, for range of moneyness values, S/X.
*   Required routines:  GAMPDF (included), B_S
*   From Numerical Recipes, Press et. al.(1992): GAMMLN,GAMMQ,GSER,GCF
*----------------------------------------------------------------------
*/

    char *putopt, *callopt, *underlying;
    const int nS=20, maxk=10000;
    const float Smin=.5,Smax=1.5,dcalltol=1.e-10;
    const float zero=0.0,one=1.0,two=2.0;
    const char printsteps='N';

    float S[nS+1+1],mu;
    
    underlying="stock";
    callopt="call";
    putopt ="put";
    
//*     Enter option and stock parameters

    float T, X, BtT, delta, sigma, gamma;
    cout << " Enter time to expiration (T) and strike price:" << endl;
    cin >> T >> X;
    cout << " Enter price of riskless, T-maturing discount bond:"
         << endl;
    cin >> BtT;
    cout << " Enter continuous dividend rate of underlying, or zero:"
         << endl;
    cin >> delta;
    cout << " Enter volatility parameters sigma and gamma:" << endl;
    cin >> sigma >> gamma;
    
//*     Define constants not depending on stock price
    float r=-log(BtT)/T;
    mu=r-delta;
    float twoless2gam=two-two*gamma;
    float twoless2gaminv=one/twoless2gam;
    float Xto2less2gam=pow(X,twoless2gam);
    float e2mugamT=exp(mu*twoless2gam*T);

    cout << "                    " << " T=" << T << " , sigma="
         << sigma << " , gamma=" << gamma << endl;
    cout << "   S/X     CEVCall   BSCall    Diff    CEVput   BSPut"
    cout << "     Diff" << endl;
    
//*     Loop over values of stock price from X*Smin to X*Smax
    for (int iS=1; iS <= nS+1; iS++) 
    {
        S[iS]=X*(Smin+(Smax-Smin)*float(iS-1)/nS);
        float sigmaonelessgamsqr=sigma*sigma*pow(S[iS],twoless2gam);
        float theta=two*mu/(sigmaonelessgamsqr*twoless2gam*
              (e2mugamT-one));
        float thetaXto2less2gam=theta*Xto2less2gam;
        float Xi=theta*e2mugamT*pow(S[iS],twoless2gam);
        
//*        Begin calculating the infinite sum for the call price...
        float CEVcall=zero;
        float dcallold=zero;
/*        
*        Find smallest k value for the gamma dists. in the formulas
*          such that thetaX and Xi are in both cases no more than 7
*          standard deviations from the mean.  This saves unnecessary
*          evaluations where there is no appreciable probability mass.
*/
        int mink1=.25*pow((sqrt(49+4*thetaXto2less2gam)-7),2);
        int mink2=.25*pow((sqrt(49+4*Xi)-7),2);
        int mink=max(mink1,mink2);
        for (int k=mink; k <= maxk; k++) 
        {
            float dk=k;
            float dkplus=k+twoless2gaminv;
            float pdf1=gampdf(Xi,dk);
            float pdf2=gampdf(Xi,dkplus);

            float cdf1, cdf2;
            if(k < 1500) 
            {
                cdf1=gammQ(dkplus,thetaXto2less2gam);
                cdf2=gammQ(dk,thetaXto2less2gam);
            }
            else 
            {
                cdf1=phi(-(thetaXto2less2gam-dkplus)/sqrt(dkplus));
                cdf2=phi(-(thetaXto2less2gam-dk)/sqrt(dk));
            }
            float dcallnew=S[iS]*pdf1*cdf1-BtT*X*pdf2*cdf2;
            CEVcall=CEVcall+dcallnew;
            if(printsteps == 'Y') 
            {
                cout << k << " " << pdf1 << " " << cdf1 << " " 
                     << pdf2 << " " << cdf2 << " " << CEVcall << endl;
                cout << "  " << dk << " " << dkplus << " " 
                     << thetaXto2less2gam << endl;
            }
            if(dcallnew < dcallold && dcallnew < dcalltol) 
                goto label_1;
            dcallold=dcallnew;
        }
//*        Reaching here indicates failure to converge!
        cout << " Sum failed to converge to tolerance" << dcalltol
             << endl;
label_1:
        float CEVput=CEVcall+BtT*X-S[iS]*exp(-delta*T);
        float BSput, BScall;
        B_S(S[iS],X,sigma,BtT,T,underlying,delta,putopt,BSput);
        B_S(S[iS],X,sigma,BtT,T,underlying,delta,callopt,BScall);
        float calldiff=CEVcall-BScall;
        float putdiff =CEVput-BSput;
        cout << "" << setiosflags(ios::fixed) << setw(6) 
             << setprecision(2) << S[iS]/X 
             << "   " << setiosflags(ios::fixed) << setw(8)
             << setprecision(4) << CEVcall 
             << " " << setiosflags(ios::fixed) << setw(8) 
             << setprecision(4) << BScall 
             << " " << setiosflags(ios::fixed) << setw(8) 
             << setprecision(4) << calldiff 
             << " " << setiosflags(ios::fixed) << setw(8) 
             << setprecision(4) << CEVput 
             << " " << setiosflags(ios::fixed) << setw(8) 
             << setprecision(4) << BSput 
             << " " << setiosflags(ios::fixed) << setw(8) 
             << setprecision(4) << putdiff << endl;
    }
    return;
}

float gampdf(float x, float a) 
{
//*     Gamma p.d.f.
    const float zero=0.0;
    const float one =1.0;

    float return_value=zero;
    if(a <= zero || x <= zero) 
    {
        cout << "Arguments of Gamma pdf must be positive!" << endl;
        return return_value;
    }
    return_value=-x+(a-one)*log(x)-gammln(a);
    return_value=exp(return_value);
    return return_value;
}



