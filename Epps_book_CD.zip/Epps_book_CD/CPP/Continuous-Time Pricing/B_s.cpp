#include <string.h>
#include <math.h>

inline float max(float a, float b) 
{
    return (a > b) ? a : b;
}

double phi(float x);

void B_S(float SS, float X, float sigma, float B, float T, const char
         *underlying,float div, const char *option, float &optval)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Calculates Black-Scholes price of European option
*     Input:     Underlying price, SS
*                Strike price, X
*                Volatility, sigma
*                Price of unit bond maturing at expiration, B
*                Expiration date, T
*                Type of underlying asset, ('stock','currency','index',
*                     or 'futures'), underlying
*                Dividend (if underlying='stock') or dividend rate
*                     (if 'underlying'='currency' or 'index'), div
*                Type of option (put or call), option
*     Output:    Value of option, optval
*     Required
*     routines:  PHI
*----------------------------------------------------------------------
*/
    float S;

    if (strcmp(underlying,"stock") == 0)
        S=SS-B*div;
    else if (strcmp(underlying, "index") == 0 ||
        strcmp(underlying, "currency") == 0)
        S=SS/exp(div*T);
    else if (strcmp(underlying,"futures") == 0)
        S=B*SS;

    float BX=B*X;

    if(S <= 0.0) 
    {
        if (strcmp(option,"call") == 0) 
            optval=0.0;
        if (strcmp(option, "put") == 0)
            optval=BX;
        return;
    }

    if (T <= 0.0) {
        if(strcmp(option,"call") == 0)
            optval=max(S-X,0.0);
        if(strcmp(option,"put") == 0)
            optval=max(X-S,0.0);
        return;
    }

    float sigrootT=sigma*sqrt(T);
    
    float q=log(BX/S)/sigrootT+0.5*sigrootT;
    optval=BX*phi(q)-S*phi(q-sigrootT);

    if(strcmp(option,"call") == 0)
        optval=optval+S-BX;
    return;
}

  


