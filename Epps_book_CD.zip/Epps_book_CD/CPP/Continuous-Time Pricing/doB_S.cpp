#include <iostream.h>

#include <string.h>
#include <stdlib.h>


void B_S(float SS, float X, float sigma, float B, float T, 
         const char *underlying,float div, const char *option,
         float &optval);


void doB_S();

int main()
{
    doB_S();
    return 0;
}

void doB_S()
{
/*
*----------------------------------------------------------------------
*     Purpose:   Executes B_S subroutine with input/output
*     Input:     Called for at execution
*     Output:    Black-Scholes prices
*     Required
*     routines:  B_S, PHI
*----------------------------------------------------------------------
*/
    char option[10], underlying[10];
    int i;
    

    cout << " Black-Scholes prices for Euro puts or calls on "
         << "stocks, indexes, currencies, or futures." << endl;
    cout << endl;
    cout << " Stocks may pay lump-sum dividends.  Indexes may pay"
         << " continuous dividends." << endl;
    for (i=1; i <= 5; i++)
        cout << endl;

    cout << "What is the underlying asset? Enter S for stock, I for"
         << " index, C for currency, F for futures." << endl;
    cout << endl;
    cin >> underlying[0];
    float div=0.0;
      
    if (underlying[0] == 's' || underlying[0] == 'S') 
    {
        cout << "Enter the sure (undiscounted) dollar value at"
             << " expiration of all lump-sum " << endl;
        cout << " dividends.  If none, enter 0." << endl;
        cout << endl;
        cin >>  div;
        strcpy(underlying,"stock");
    }
    else if (underlying[0] == 'i' || underlying[0] == 'I') 
    {
        cout << "Enter average, annualized, continuously-compounded"
             << " dividend rate" << endl;
        cout << " during life of option.  If none, enter 0." << endl;
        cout << endl;
        cin >> div;
        strcpy(underlying,"index");
    }
    else if (underlying[0] == 'c' || underlying[0] == 'C') 
    {
        cout << "Enter foreign minus domestic interest rate; e.g., "
             << ".02,-.01 ..." << endl;
        cin >> div;
        strcpy(underlying,"currency");
    }
    else if (underlying[0] == 'f' || underlying[0] == 'F') 
    {
        strcpy(underlying,"futures");
    }
    else 
    {
        cout << "Underlying must be one of S,I,C or F!" << endl;
        exit(1);
    }
    
    cout << "Enter CALL or PUT for the type of option..." << endl;
    cout << endl;
    cin >> option;
    cout << "Enter, separated by spaces or commas..." << endl;
    cout << "  1. the initial value of the underlying" << endl;
    cout << "  2. the strike price" << endl;
    cout << "  3. the annualized volatility" << endl;
    cout << "  4. the time to expiration in years, T" << endl;
    cout << "  5. the present value of a sure payment of $1 at T"
         << endl;
    cout << endl;

    float S, X, sigma, T, B;
    cin >> S >> X >> sigma >> T >> B;

    for (i=1; i <= 25; i++)
         cout << endl;
    
    float optval;
    B_S(S,X,sigma,B,T,underlying,div,option,optval);
    
    cout << "               " << "Initial value of underlying "
         << underlying << ":" << "     " << S << endl;
  
    if(strcmp(underlying,"stock") == 0)
        cout << "               " << "Dividend: " << "                              " << div << endl;
      
    if(strcmp(underlying,"index") == 0)
        cout << "               " << "Dividend rate: " << "                         " << div << endl;
      
    cout << "               " <<  "Strike price: " << "                            " << X << endl;
    cout << "               " << "Years to expiration:" << "                      " << T << endl;
    cout << "               " << "Price of $1 discount bond:" << "                " << B << endl;
    cout << endl;
    
    cout << "               " << "Value of European " << option
         << ":" << "                 " << optval << endl;
    for (i=1; i <= 7; i++)
        cout << endl;

    return;
}
      


