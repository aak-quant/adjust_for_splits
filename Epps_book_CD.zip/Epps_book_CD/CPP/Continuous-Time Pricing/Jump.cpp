#include <iostream.h>

#include <string.h>
#include <math.h>

void B_S(float SS, float X, float sigma, float B, float T, 
         const char *underlying,float div, const char *option,
         float &optval);

void Merton(float S0, float X, float sigma, float B0T, float T,
            double nu,float xi, float theta, float &put,
            float &call);
void jump();

int main()
{
    jump();
    return 0;
}

float div;
char *putopt,*callopt,underlying[10];

void jump()
{
/*
*----------------------------------------------------------------------
*     Purpose:   Value European put or call on underlying following
*                mixed jump-diffusion dynamics.
*     Inputs:    Called for at execution.
*     Output:    Price of European option.
*     Required routines: B_S, PHI
*----------------------------------------------------------------------
*/
    
    char option[4];
    float nu;
    putopt="put";
    callopt="call";
    
    float X, T, B0T, S0;
    
    cout << "Enter type of European option to be priced (put, call)..."
         << endl;
    cin >> option;
    cout << "Enter strike price of option..." << endl;
    cin >> X;
    cout << "Enter option life (T) and price of T-maturing bond:" 
         << endl;
    cin >> T >> B0T;
    cout << "What is the underlying asset: stock, index, or currency? "
         << endl;
    cout << "Enter one of these..." << endl;
    cin >> underlying;
    cout << "Enter initial price of underlying..." << endl;
    cin >> S0;

    if (strcmp(underlying,"stock") == 0) {
        cout << "Enter value at time T of all lump-sum dividends paid " 
             << "over life of option " << endl;
        cout << "and reinvested at riskless rate:" << endl;
        cin >>  div;
        S0=S0-B0T*div;
    } 
    else if (strcmp(underlying,"index") == 0){
        cout << "Enter continuous dividend rate paid by the index..."
             << endl;
        cin >>  div;
        S0=S0/exp(T*div);
    } 
    else if (strcmp(underlying,"currency") == 0) {
        cout << "Enter difference between foreign and domestic annual"
             << endl;
        cout << "interest rates: e.g., .02 or -.01" << endl;
        cin >>  div;
        S0=S0/exp(T*div);
    }

    div=0.0;
    float sigma, theta, xi;
    
    cout << "Enter volatility of diffusion part of underlying (sigma)"
        << "..." << endl;
    cin >>  sigma;
    
    cout << "Enter mean jump rate (theta) and mean and volatility of "
         << "jump shocks " << endl;
    cout << "(nu and xi)..." << endl;
    cin >> theta >> nu >> xi;
    
    float putj, callj;
    Merton(S0,X,sigma,B0T,T,nu,xi,theta,putj,callj);
    
    if (strcmp(option,"put") == 0) 
        cout << "Price of European put: " << putj << endl;
    else
        cout << "Price of European call:" << callj << endl;

    return;
}


void Merton(float S0, float X, float sigma, float B0T, float T,
            double nu,float xi, float theta, float &put,
            float &call) 
{
    const float zero=0.0, one=1.0, tol=1.0e-6;
    const int maxn=1000;
    const char writeit='y';
    
//*          Check for trivial case...
    float xiplusnu=xi+fabs(nu);
    
    if (theta == zero || xiplusnu == zero) {
//*        B-S applies
        B_S(S0,X,sigma,B0T,T,underlying,div,callopt,call);
        B_S(S0,X,sigma,B0T,T,underlying,div,putopt,put);
        return;
    }

//*     Define second-order parameters...
    float tolbyX=tol/X;
    float oneplusnu=one+nu;
    float thetaTnu=theta*T*oneplusnu;
    float Pn=exp(-thetaTnu);
    float Qn=Pn;
    float B0Tthetanu=B0T*exp(theta*T*nu);
    float sigmasqr=sigma*sigma;
    float xisqrbyT=xi*xi/T;
    
//*     Begin cumulating put value...
    put=zero;

    for (int n=0; n <= maxn; n++) 
    {
        float Bn=B0Tthetanu/pow(oneplusnu,n);
        float sigman=sqrt(sigmasqr+n*xisqrbyT);
        float putn;
        B_S(S0,X,sigman,Bn,T,underlying,div,putopt,putn);
        if (n > 0) {
            Pn=Pn*thetaTnu/n;
            Qn=Qn+Pn;
        }
        put =put +Pn*putn;
        if (writeit == 'y') 
            cout << put << " " << Pn  << " " << Bn  << " " <<  sigman
                 << endl;
        
        if (one-Qn < tolbyX) {
//*         get call by p-c parity.(Note S0 already dividend-adjusted.)
            call=S0-B0T*X+put;
            return;
        }
    }
    
    cout << "! Merton did not converge to tolerance " << tol << endl;
    return;
}


