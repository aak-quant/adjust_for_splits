#include <iomanip.h>
#include <iostream.h>
#include <math.h>

typedef int bool;

void B_S(float SS, float X, float sigma, float B, float T,
         const char *underlying,float div, const char *option,
         float &optval);
double phi(float x);

void zbrac(float (*atmoney)(float), float *v1, float *v2);
float rtbis(float (*atmoney)(float), float v1, float v2, float );
float gaussint(float (*f1)(float), float q11, float,float);

float atmoney(float v);
float f1(float z);
float f2(float z);
void compound();

int main() 
{
    compound();
    return 0;
}

float M,X,BtstarT,sigma,Tlesststar;
float rttratio,q21,q22;

void compound()
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Value compound call option (call on a call)
*     Input:     Initial value & volatility of underlying
*                Strikes of compound & primary
*                Expiration times of commpound & primary
*     Output:    Value of compound call
*     Reference: Geske, R. (1979), "Valuation of compound options,"      
*                J.Financial Econ. 7, 63-91.
*     Required routines: B_S, PHI, Gaussint
*     From Numerical Recipes, Press et. al. (1992): ZBRAC, RTBIS
*----------------------------------------------------------------------
*/
    float integral1,integral2;
    float v1,v2;
    char *underlying, *option;

    float V0, tstar, T, B0tstar;
    
//*     Enter characteristics of the options

    cout << "Enter current value & volatility of underlying:" << endl;
    cin >> V0 >> sigma;
    cout << "Enter strike prices of (1) compound (2) primary:" << endl;
    cin >> X >> M;
    cout << "Enter times to exp. of compound (t*) & primary (T)"
          << endl;
    cin >> tstar >> T;
    cout << "Enter bond prices B(t,t*),B(t*,T):" << endl;
    cin >> B0tstar >> BtstarT;

    float compoundcall;
    Tlesststar=T-tstar;
    if (Tlesststar == 0.0) 
    {
//*        Deal with case that the two options expire at the same time.
        if (BtstarT != 1.0) 
        {
            cout << "If t*=T then B(t*,T) must equal unity!" << endl;
            cout << "Enter bond prices again." << endl;
            cin >> B0tstar >> BtstarT;
        }
        underlying="stock";
        option="call";
        B_S(V0,M+X,sigma,B0tstar,T,underlying,0.,option,compoundcall);
        goto label_1;
    }
    
//* Find value of primary asset, vX, that puts primary call at money.
    v1=V0/2.0;
    v2=v1+1.0;
    zbrac(atmoney,&v1,&v2);
    
    float vX=rtbis(atmoney,v1,v2,10.e-6);
    
//*     Define needed quantities...
    float B0T=B0tstar*BtstarT;
    float sigrttstar=sigma*sqrt(tstar);
    float rtTlesststar=sqrt(Tlesststar);


    rttratio=sqrt(tstar/(T-tstar));
    float q11=log(B0tstar*vX/V0)/sigrttstar-0.5*sigrttstar;
    float q12=q11+sigrttstar;
    q21=-log(B0T*M/V0)/(sigma*rtTlesststar)+0.5*sigma*T/rtTlesststar;
    q22= q21-sigma*T/sqrt(Tlesststar);
    float q3 =-log(B0tstar*vX/V0)/sigrttstar-0.5*sigrttstar;


//*     Begin the calculations...
    integral1=gaussint(f1,q11,1000.0,0.001);
    integral2=gaussint(f2,q12,1000.0,0.001);


    compoundcall=V0*integral1-B0T*M*integral2-B0tstar*X*phi(q3);
    
label_1:
    cout << "Value of the compound call:"  << setiosflags(ios::fixed)
         << setw(8) << setprecision(3) << compoundcall << endl;
    return;
}


float f1(float z) 
{
    return phi(z*rttratio+q21);
}


float f2(float z)
{
    return phi(z*rttratio+q22);
}

float atmoney(float v)
{
//*     Finds intrinsic value of compound call on call on primary asset.
    char *option,*underlying;
    float S,div;
    
    option="call";
    underlying="stock";
    div=0.0;

      
    B_S(v,M,sigma,BtstarT,Tlesststar,underlying,div,option,S);

    return S-X;
}



