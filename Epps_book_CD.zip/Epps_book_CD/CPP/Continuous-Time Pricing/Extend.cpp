#include <iostream.h>

#include <math.h>
#include <string.h>
#include <stdlib.h>


double phi(float x);
void B_S(float SS, float X, float sigma, float B, float T, 
         const char *underlying,float div, const char *option,
         float &optval);
float gaussint(float (*f1)(float), float q11, float,float);


float f1(float z);
float f2(float z);
void extend();

int main()
{
    extend();
    return 0;
}


    
float rttstarbyT,q21,q22;
          
void extend() 
{
/*
*----------------------------------------------------------------------
*     Purpose:   Value a put on a no-dividend stock that must be
*                exercised if in the money at t* and is otherwise
*                extended to T.
*     Inputs:    Called for at execution
*     Output:    Values of European puts expiring at t* and T,
*                and value of the extendable put
*     Required
*     routines:  B_S, PHI, GAUSSINT
*----------------------------------------------------------------------
*/
    float integral1,integral2;
    
    char *underlying, *option;
    float S0, sigma, tstar, T, B0tstar, B0T, X;

//*     Enter characteristics of stock, bonds, and extendable put...
    option="put";
    underlying="stock";
    cout << "Enter current stock price and volatility..." << endl;
    cin >> S0 >> sigma;
    cout << "Enter times to extension (t*) and expiration (T)..."
         << endl;
    cin >>  tstar >> T;
    cout << "Enter prices of riskless discount bonds maturing t* & T."
         << endl;
    cin >>  B0tstar >> B0T;
    cout << "Enter strike price of the put..."<< endl;
    cin >>  X;
    
    float div=0.0;
//*     Compute some oft-used values
    rttstarbyT=sqrt(tstar/(T-tstar));
    float q11=(log(B0tstar*X/S0)+.5*tstar*(sigma*sigma))/
          (sigma*sqrt(tstar)); // expanded square
    float q12=q11-sigma*sqrt(tstar);
    q21=(log(B0T*X/S0)+.5*T*(sigma*sigma))/(sigma*sqrt(T-tstar));
          // expanded square
    q22=(log(B0T*X/S0)-.5*T*(sigma*sigma))/(sigma*sqrt(T-tstar));
         // expanded square
    
//*     Begin the calculations...
    integral1=gaussint(f1,q11,1000.0,0.001);
    integral2=gaussint(f2,q12,1000.0,0.001);

    float puttstar;
    B_S(S0,X,sigma,B0tstar,tstar,underlying,div,option,puttstar);
    float putT;
    B_S(S0,X,sigma,B0T,T,underlying,div,option,putT);
    
    float extendput=puttstar+B0T*X*integral1-S0*integral2;
    cout << "Euro put expiring at t*:     P(0,t*)=" << puttstar 
         << endl;
    cout << "Euro put expiring at T:       P(0,T)=" << putT 
         << endl;
    cout << "Euro put extendable at t*: P(0,t*,T)=" << extendput 
         << endl;
    
    return;
}
    
float f1(float z)
{
    float rv = phi(-z*rttstarbyT+q21);
    return rv;
}

float f2(float z)
{
    float rv = phi(-z*rttstarbyT+q22);
    return rv;

}



