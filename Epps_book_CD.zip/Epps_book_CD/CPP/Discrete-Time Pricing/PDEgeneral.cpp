#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>

#include <string.h>
#include <math.h>
#include <stdlib.h>


void PDEgeneral();
float RFUNCTION(float t);
float CASHFUNCTION(float t, float s);
float MUFUNCTION(float r, float dividend, float t, float s);
float SIGMAFUNCTION(float sigma, float t, float s);
void GRID(int &jSo, float So, float SminbySo, float SmaxbySo,
          float S[], float f[], float &ds,int nS, float T,
          float &dt,int &nT, const char *derivative, float strike);
float INTRINSIC(const char *derivative, float strike, float S);



inline float max(float a, float b) 
{
    return (a > b) ? a : b;
}

inline float min(float a, float b) 
{
    return (a < b) ? a : b;
}

inline int max(int a, int b) 
{
    return (a > b) ? a : b;
}

inline int min(int a, int b) 
{
    return (a < b) ? a : b;
}

inline int round(float f) 
{
    return floor(f+0.5);
}



int main()
{
    PDEgeneral();
    return 0;
}


/*    
*----------------------------------------------------------------------
*     Purpose:   Solve financial PDE by Crank-Nicholson method, allowing
*                for time-varying interest rates and time- and price-
*                dependent cash flow, mean drift, and volatility.
*     Input:     Values in parameter statements as instructed in routine.
*                Specify interest-rate, cash flow, drift, and volatility
*                processes in function subprograms.  Examples supplied.
*     Output:    Option value over range of prices around the strike.
*     Reference: Smith, G. (1985) Numerical Solution of Partial
*                Differential Equations, 3d ed., Clarendon Press: Oxford
*     Required routines:  None
*----------------------------------------------------------------------
*/

void PDEgeneral() 
{
    int i, j;

//*     Designate output file...
    const char *outfile="new.out";

/*
*     Set parameters and options for derivative security...
*        timetomaturity   (in years)
*        strike           (in dollars)
*        derivative     = "put" or "call"
*        type           = "American" or "European"
*/
    const float timetomaturity =  1.0;
    const float strike         =  1.0;
    const char *derivative     = "put";  
    const char *type           = "European";

/*
*     Set parameters of process for underlying asset...
*        So             =    initial stock price
*        sigma          =    parameter to calculate volatility of return
*        dividend       =    annualized continuous dividend rate
**    Note: This version handles only continuously-paid dividends. ***
*/

    const float So             =  1.0;
    const float sigma          =  0.5;
    const float dividend       =  0.0;

/*
*     Set parameters and options for finite-difference method...
*        SminbySo       =  min stock price relative to initial price
*        SmaxbySo       =  max stock price relative to initial price
*        nS             =  number of stock prices in grid
*/

    const float SminbySo       = 0.0;
    const float SmaxbySo       = 4.0;
    const int nS             = 40;

    float c[nS-1+1], k[nS+1], l[nS+1], f[nS+1], S[nS+1];

    float mu, mudtby4ds;
    
//*     Initialize working parameters...

    static float one = 1.0;
    static char *Method = "Crank-Nicholson";

//* Set up price/time grid & boundary values: f(s,T),f(Smin,t),f(Smax,t).
    int jSo, nT;
    float ds, dt;
    GRID(jSo,So,SminbySo,SmaxbySo,S,f,ds,nS,timetomaturity,dt,nT,
         derivative,strike);
    

//*     Define constants that don't change with time or stock price...
    float dtby4ds    = dt/(4*ds);
    float dtby4dssqr = dtby4ds/ds;
    float dtby2dssqr = 2*dtby4dssqr;
    
/*
* Working back from time step nT-1, solve for each f(s,t) at each t<T.
* (Terminal values f(s,T) were determined by the boundary conditions.)
*/
    for (i = nT-1; i >= 0; i--)
    {
        float t=i*dt;
//*     Get the current continuous riskless rate.
        float r = RFUNCTION(t);
        float rdt = r*dt;
        float oneplusrdt = one+rdt;
        
        if (strcmp(type, "European") == 0) 
        {
//*     Recalculate boundary value f(Smin,t) or f(Smax,t), which
//*     for Euro options depend on time to maturity...
            if(strcmp(derivative,"put") == 0) 
                f[0] = strike*exp(-(nT-i)*rdt);
            else if (strcmp(derivative,"call") == 0)
                f[nS] = S[nS]-strike*exp(-(nT-i)*rdt);
            
        }

//*        Loop over price steps to find time/price-dependent coefs...
        for (j=1; j <= nS-1; j++) 
        {
/*            
*           Determine the derivative's cash flow and asset's volatility
*             and mean drift for this time and price level...
*/
            float cash        = CASHFUNCTION(t,S[j]);
            float sigmasqr    = pow(SIGMAFUNCTION(sigma,t,S[j]), 2);
            mu          = MUFUNCTION(r,dividend,t,S[j]);
            mudtby4ds   = mu*dtby4ds;
            float sigmasqrdtby2dssqr = sigmasqr*dtby2dssqr;
            float sigmasqrdtby4dssqr = sigmasqr*dtby4dssqr;

//*         Set up the a*,b*,c* and a,b,c coefficients...
            float astar = -mudtby4ds+sigmasqrdtby4dssqr;
            float bstar =  one-sigmasqrdtby2dssqr;
            float cstar =  mudtby4ds+sigmasqrdtby4dssqr;
            float a     = -astar;
            float b     =  oneplusrdt+sigmasqrdtby2dssqr;
            c[j]  = -cstar;
            float g     =  cash*dt+astar*f[j-1]+bstar*f[j]+cstar*f[j+1];
            
/*
*           Evaluate the l and k coefficients from which the linear
*              functions of new f's are constructed as
*              k[j] = l[j]*f[j]+c[j]*f[j+1], for j=1,...,nS.
*/
            if (j == 1) 
            {
                l[j] = b;
                k[j] = g-a*f[0];
            }
            else
            {
                l[j] = b-a*c[j-1]/l[j-1];
                k[j] = g-a*k[j-1]/l[j-1];
            }
        }
        
//*  Loop over price steps again to calculate the new f(nS-1)...f(1) ...
        for (j=1; j <= nS-1; j++)
            f[nS-j] = (k[nS-j] - c[nS-j]*f[nS-j+1])/l[nS-j];


        if(strcmp(type, "American") == 0) 
        {
//*        allow for possibility of early exercise...
            for (j=1; j<= nS-1; j++)
                f[j] = max( f[j], INTRINSIC(derivative,strike,S[j]) );
        }
    }
    

//*  Write out value of option for each stock price near initial value.

    ofstream file1(outfile);
    
    file1 << "   " << setw(15) << Method 
          << " finite-difference valuation of " << setw(8) << type 
          << setw(5) << derivative << endl;
    cout  << "   " << setw(15) << Method 
          << " finite-difference valuation of " << setw(8) << type 
          << setw(5) << derivative << endl;
    
    file1 << "             Strike price:             " << strike 
          << endl  
          << "             Time to maturity (years): " << timetomaturity
          << endl
          << "             Initial stock price:      " << So << endl
          << "             Annualized dividend rate: " << dividend 
          << endl
          << "                     Stock     Option  " << endl
          << "                     Price      Value  " << endl
          << "                    ^^^^^^^   ^^^^^^^^ " << endl;

    cout  << "             Strike price:             " << strike 
          << endl  
          << "             Time to maturity (years): " << timetomaturity
          << endl
          << "             Initial stock price:      " << So << endl
          << "             Annualized dividend rate: " << dividend
          << endl
          << "                     Stock     Option  " << endl
          << "                     Price      Value  " << endl
          << "                    ^^^^^^^   ^^^^^^^^ " << endl;

    int jlo = max(jSo-5,0);
    int jhi = min(jSo+5,nS);

    for (j=jlo; j <= jhi; j++) 
    {
        if(j == jSo || j == jSo+1) cout << endl;
        cout  << "                     " << setiosflags(ios::fixed)
              << setw(6) << setprecision(3) << S[j];
        cout  << "  " << setiosflags(ios::fixed) << setw(8)
              << setprecision(4) << f[j] << endl;
        file1 << "                     " << setiosflags(ios::fixed)
              << setw(6) << setprecision(3) << S[j];
        file1 << "  " << setiosflags(ios::fixed) << setw(8)
              << setprecision(4) << f[j] << endl;
    }
}


float RFUNCTION(float t)
{
//*     Specify the riskless rate as a function of time.
    return 0.20+0*t;
}

float CASHFUNCTION(float t, float s)
{
/*    
*     Specify any cash flow generated by the derivative.
*     If none, set cashfunction=0.
*/
    return 0*s+0*t;
}


float MUFUNCTION(float r, float dividend, float t, float s)
{
//*     Specify mean drift of asset price.
    return (r-dividend)*s+0*t;
}


float SIGMAFUNCTION(float sigma, float t, float s)
{
/*    
*     Specify volatility of asset price.  If asset follows geometric
*       B.m., set sigmafunction=sigma*s.
*/
    return sigma*s+0*t;
}



void GRID(int &jSo, float So, float SminbySo, float SmaxbySo,
          float S[], float f[], float &ds,int nS, float T, float &dt,
          int &nT,const char *derivative, float strike)
{
/*
*     Set up dimensions of the grid, the price/time steps, values of
*         stock price, and the boundary values of the derivative
*/
    ds=So*(SmaxbySo-SminbySo)/nS;
    
    jSo=round(So*(1.0-SminbySo)/ds);
    
//*        =price step corresponding to initial stock price.
    S[0]=So*SminbySo;
    f[0]=INTRINSIC(derivative,strike,S[0]);
    for (int i=1; i <= nS; i++) 
    {
        S[i]=S[i-1]+ds;
        f[i]=INTRINSIC(derivative,strike,S[i]);
    }

    nT=round(T/(ds*ds));
    dt=T/nT;
}



float INTRINSIC(const char *derivative, float strike, float S)
{
//*     Specify intrinsic value of the option...
    const float zero = 0.0;
    
    if(strcmp(derivative,"put") == 0) 
         return max(zero,strike-S);
    else if(strcmp(derivative,"call") == 0)
        return max(zero,S-strike);
}



