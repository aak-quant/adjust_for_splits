#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>

#include <string.h>
#include <math.h>
#include <stdlib.h>


void PDEgeoBm();
void BOUNDARY(const char *derivative, int& nS, float So, 
              float strike, float& Zmin, float Zmax,float dz,
              float f[1001], float S[1001]);
float INTRINSIC(const char *derivative, float strike, float S);

inline float max(float a, float b) 
{
    return (a > b) ? a : b;
}

inline float min(float a, float b) 
{
    return (a < b) ? a : b;
}

inline int max(int a, int b) 
{
    return (a > b) ? a : b;
}

inline int min(int a, int b) 
{
    return (a < b) ? a : b;
}


int jSo;


int main()
{
    PDEgeoBm();
    return 0;
}

/*
*----------------------------------------------------------------------
*  Purpose:   Solve the financial PDE when price follows geometric
*             Brownian motion by choice of EXPLICIT, first-order
*             IMPLICIT, or CRANK-NICHOLSON methods.
*  Input:     Values in parameter statements as instructed in routine.
*  Output:    Option value over range of prices around the strike.
*  Reference: Smith, G. (1985) Numerical Solution of Partial
*             Differential Equations, 3d ed., Clarendon Press: Oxford
*  Required routines:  None
*----------------------------------------------------------------------
*/
void PDEgeoBm()
{
    int j;
    const char* outfile = "pde.out";
    
/*
*     Set parameters and options for derivative security...
*        timetomaturity   (in years)
*        strike           (in dollars)
*        derivative     = "put" or "call"
*        type           = "American" or "European"
*/
    const float timetomaturity = 1.0;
    const float strike         = 1.0;
    const char *derivative     = "put";
    const char *type           = "American";

/*    
*     Set parameters of process for underlying asset...
*        So             =    initial stock price
*        sigma          =    annualized volatility of return
*        r              =    annualized continuous riskless rate
*        dividend       =    annualized continuous dividend rate
**    Note: This version handles only continuously-paid dividends. ***
*/
    const float So             = 1.0;
    const float sigma          = 0.5;
    const float r              = 0.20;
    const float dividend       = .00;

/*    
*     Set parameters and options for finite-difference method...
*        Method         = "Explicit", "Implicit", or "Crank-Nicholson"
*        nT             =  number of time intervals
*        Zmax           =  log(max stock price) = -log(min stock price)
*        nSmax          =  maximum number of stock prices
*/
    const char* method         = "Explicit";
//    const char* method         = "Implicit";
//    const char* method         = "Crank-Nicholson";

    const int nT               =  100;
    const float Zmax           =    7.0;
    const int nSmax            = 1000;

    float k[nSmax+1], l[nSmax+1], f[nSmax+1], fold[nSmax+1], S[nSmax+1];
    

//*     Initialize working parameters...
    float one = 1.0, two = 2.0;
    float Zmin = -Zmax;
    
    float dt = timetomaturity / nT;
    float rdt = r * dt;
    float deltadt = dividend * dt;
    float dz = sigma * sqrt(3.0*dt);
    float twodz = two * dz;
    float sigmasquaredt = sigma*sigma*dt;
    
    ofstream file1(outfile);
    
    if ( strcmp(method, "Crank-Nicholson") == 0) 
    {
        file1 << "   " << setw(15) << method 
              << " finite-difference estimate of value of "
              << setw(8) << type << setw(5) << derivative << endl;
        cout  << "   " << setw(15) << method 
              << " finite-difference estimate of value of "
              << setw(8) << type << setw(5) << derivative << endl;
    }
    else
    {
        file1 << "   " << setw(8) << method 
              << " finite-difference estimate of value of "
              << setw(8) << type << setw(5) << derivative << endl;
        cout  << "   " << setw(8) << method 
              << " finite-difference estimate of value of "
              << setw(8) << type << setw(5) << derivative << endl;
    }
    
    file1 << "             Strike price:             " << strike 
          << endl  
          << "             Time to maturity (years): " 
          << timetomaturity << endl
          << "             Initial stock price:      " << So << endl
          << "             Annualized volatility:    " << sigma << endl
          << "             Annualized riskless rate: " << r << endl
          << "             Annualized dividend rate: " << dividend
          << endl
          << "                     Stock     Option  " << endl
          << "                     Price      Value  " << endl
          << "                    ^^^^^^^   ^^^^^^^^ " << endl;
    
    cout  << "             Strike price:             " << strike 
          << endl  
          << "             Time to maturity (years): " << timetomaturity
          << endl
          << "             Initial stock price:      " << So << endl
          << "             Annualized volatility:    " << sigma << endl
          << "             Annualized riskless rate: " << r << endl
          << "             Annualized dividend rate: " << dividend 
          << endl
          << "                     Stock     Option  " << endl
          << "                     Price      Value  " << endl
          << "                    ^^^^^^^   ^^^^^^^^ " << endl;
    
//*     Set boundary conditions for specific derivative being priced...
    int nS;
    BOUNDARY(derivative,nS,So,strike,Zmin,Zmax,dz,f,S);

//*     Set coefficients of f's for the various methods...

    float c1 = (rdt-deltadt-sigmasquaredt/two)/(twodz);
    float c2=sigmasquaredt/(twodz*dz);
    
    float a,b,c;
    float astar, bstar, cstar;
    float c3;
    
    if (strcmp(method,"Implicit") == 0) {
        a=c1-c2;
        b=one+rdt+two*c2;
        c=-c1-c2;
    }
    else if( strcmp(method,"Crank-Nicholson") == 0) 
    {
        a=c1-c2;
        b=two+two*rdt+two*c2;
        c=-c1-c2;
        astar=-a;
        bstar=two-two*c2;
        cstar=-c;
    }
    else if( strcmp(method,"Explicit") == 0) 
    {
        c3=one+rdt;
        astar=(c2-c1)/c3;
        bstar=(one-two*c2)/c3;
        cstar=(c1+c2)/c3;
    }

    if(strcmp(method, "Implicit") == 0 || 
       strcmp(method,"Crank-Nicholson") == 0) {
/*
*        Evaluate the time-independent coefficients, l's, from
*           which the linear functions of new f's are constructed as
*           k(j)=l(j)*f(j)+c*f(j+1), for j=1,...,nS.
*/

        k[0] = f[0];
        l[0] = one;
        l[1] = b;

        for (j = 2; j <= nS-1; j++)
            l[j] = b - a*c/l[j-1];
    }

/*
*     Starting at time nT-1 and working back, solve for the new f's...
*     (The f's at nT are defined by the boundary conditions.)
*/

    for (int i = nT-1; i >= 0; i--) 
    {
/*
*        Value European put at lower price boundary and European call
*           at upper boundary.  These depend on the time to maturity...
*/
        if (strcmp(type, "European") == 0) 
        {
            if(strcmp(derivative, "put") == 0) 
                f[0] = strike*exp(-(nT-i)*rdt);
            else if(strcmp(derivative,"call") == 0)
                f[nS] = S[nS]-strike*exp(-(nT-i)*rdt);
        }


        if (strcmp(method, "Explicit") == 0) 
        {
            for (j = 0; j <= nS; j++)
                fold[j] = f[j];
//*           Calculate the new f(1)...f(nS-1) ...        
            for (j = 1; j <= nS-1; j++)
                f[j] = astar*fold[j-1] + bstar*fold[j] + cstar*fold[j+1];
        }
        else 
        {
//*           Calculate the time-dependent coefficients, k(j) ...
            if (strcmp(method, "Implicit") == 0) 
            {
                for (j = 1; j <= nS-1; j++)
                    k[j] = f[j] - a*k[j-1]/l[j-1];
            }
            else if (strcmp(method, "Crank-Nicholson") == 0) 
            {
                for (j=1; j <= nS-1; j++)
                {
                  float g    = astar*f[j-1] + bstar*f[j] + cstar*f[j+1];
                  k[j] = g - a*k[j-1]/l[j-1];
                }
            }
            
//*           and calculate the new f(nS-1)...f(1) ...

            for (j=1; j <= nS-1; j++)
                f[nS-j] = (k[nS-j] - c*f[nS-j+1]) / l[nS-j];
        }
        
        if( strcmp(type,"American") == 0) {
//*        allow for possibility of early exercise...
            for (j=1; j <= nS-1; j++)
              f[j] = max( f[j], INTRINSIC(derivative, strike, S[j]) );
        }
                
    }



//*  Write out value of option for each stock price near initial value.

    
    int jlo = max(jSo-5, 0);
    int jhi = min(jSo+5,nS);
    
    for (j = jlo; j <= jhi; j++) 
    {
        if (j == jSo || j == jSo+1) 
         cout << endl;
         
         cout  << "                     " << setiosflags(ios::fixed)
               << setw(6) << setprecision(3) << S[j];
         cout  << "  " << setiosflags(ios::fixed) << setw(8)
               << setprecision(4) << f[j] << endl; 
         file1 << "                     " << setiosflags(ios::fixed)
               << setw(6) << setprecision(3) << S[j];
         file1 << "  " << setiosflags(ios::fixed) << setw(8)
               << setprecision(4) << f[j] << endl; 
    }
    
}


float INTRINSIC( const char *derivative, float strike, float S) 
{
//*     Specify intrinsic value of the option...
    const float zero = 0.0;
    
    if (strcmp(derivative, "put") == 0) 
        return max(zero, strike-S);
    else 
        return max(zero, S-strike);
}



//  integer "jSo" is declared globally at the top of this file.

void BOUNDARY(const char *derivative, int& nS, float So, float strike,
              float& Zmin, float Zmax, float dz, float f[1001],
              float S[1001])
{
    const int nSmax = 1000;  // sizes of f and S

    const float zero = 0.0;
    
    
//* Set first nonzero stock price so that So is an element of S...
    jSo = (int) ((log(So) - Zmin)/ dz);       
    Zmin = log(So) - jSo*dz;
    
//*     Calculate number of nonzero stock prices in the grid, nS...

    nS = (Zmax-Zmin)/dz;

    if (nS >= nSmax) 
    {
        //      if(nS.ge.nSmax) pause 'Increase nSmax and restart!'
        cerr << "Increase size of arrays and restart!" << endl;
        exit(1);
    }
    
    float z = Zmin;
    S[0] = zero;
    f[0] = INTRINSIC(derivative,strike,S[0]);

    for(int j=1; j <= nS; j++) 
    {
        z=z+dz;
        S[j]=exp(z);
        f[j]=INTRINSIC(derivative,strike,S[j]);
    }

    return;
}



