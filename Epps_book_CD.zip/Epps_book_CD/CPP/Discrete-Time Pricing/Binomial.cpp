#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>

#include <string.h>
#include <math.h>
#include <stdlib.h>


inline float max(float a, float b) 
{
    return (a > b) ? a : b;
}

inline float min(float a, float b) 
{
    return (a < b) ? a : b;
}

inline int max(int a, int b) 
{
    return (a > b) ? a : b;
}

inline int min(int a, int b) 
{
    return (a < b) ? a : b;
}

inline int round(float f) 
{
    return floor(f+0.5);
}



void binomial();float intrinsic(const char *option, float s);


int main()
{
    binomial();
    return 0;
}

void binomial() 
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Prices European, American, and extendable options on
*                stocks, currencies, indexes, or futures under 
*                Bernoulli dynamics
*     Inputs:    Called for on execution
*     Output:    Summary of input data and value of option
*     Required
*     routines:  none
*----------------------------------------------------------------------
*     Pricing European, American, and extendable options on stocks,
*       indexes, or futures.
*/

    char option[80], type[80], underlying[80];
    char divtype;
    
    const char printit = 'n';
    const int maxn=1000,maxTX=5,maxdiv=5;
    
    float O[maxn+1],TX[maxTX+1],Tdiv[maxdiv+1],propdiv[maxdiv+1];
    float fixeddiv[maxdiv+1],lnu,intrinsicvalue;
    int nTX[maxTX+1],nTdiv[maxdiv+1],step;
    int j, id;

    int i;
    for (i = 0; i <= maxTX; i++)
        TX[i] = 0.0;

    float divrate = 0.0;

    for (i = 0; i <= maxdiv; i++)
        Tdiv[i] = 0.0;

    nTX[0] = maxn;
    for (i = 1; i <= maxTX; i++)
        nTX[i] = 0;

    for (i = 0; i <= maxdiv; i++)
        nTdiv[i] = 0;

    int ndiv = 0;
    
    cout << "           ********************************************"
         << "**********" << endl;
    
    cout << "           Binomial pricing of European or American cal"
         << "ls or puts" << endl;
    cout << "           ********************************************"
         << "**********" << endl;
    cout << endl;
    cout << "           Underlying asset may be stock, stock index, "
         << "or futures." << endl;
    cout << "           Stock or index may pay proportional dividend"
         << "s, at given" << endl;
    cout << "            dates or continuously." << endl;
    cout << endl;
    cout << "           Option may be extendable at times before"
         << " final expiration." << endl;
    cout << endl;
    cout << "           When prompted, enter the number of subperio"
         << "ds for the" << endl;
    cout << "            binomial approximation and data for option"
         << " and asset." << endl;
    cout << "           *******************************************"
         << "***********" << endl;
    cout << endl;

//*     Enter data and check for bad inputs...
label_1:
    cout << " Enter number of subperiods for the binomial"
         << " approximation (0 < n < 1000): " << endl;
    int n;
    cin >> n;
    if (n <= 0 || n > 1000) {
        cout << " Number of periods must be positive integer < 1000!"
             << endl;
        goto label_1;
    }

    cout << endl;
    cout << " Enter option data..." << endl;
    cout << endl;

label_2:
    cout << " Enter form of option, as \"call\" or \"put\": " << endl;
    cin >> option;
    if (strcmp(option, "call") != 0 && strcmp(option,"put") != 0) {
        cout <<  option << " is invalid: must be \"call\" or \"put\""
             << endl;
        goto label_2;
    }

label_3:
    cout << " Enter type of option--\"American\" or \"European\": "
         << endl;
    cin >> type;
    if (strcmp(type,"American") != 0 && strcmp(type,"European") != 0) 
        { cout <<  type << " is invalid: must be \"American\" or 
          \"European\"" << endl;
        goto label_3;
    }

    cout << " Enter time to expiration in years, as decimal number."
         << endl;
    cout << " For an extendable option, this should be the FINAL"
         << " exercise date: " << endl;
    float T;
    cin >> T;

label_4:
    cout << " If option is extendable, enter number of extension"
         << " dates. " << endl;
    cout << " If not extendable, enter 0: " << endl;
    int mTX;
    cin >> mTX;
    if (mTX > 0) {
        cout << " Enter times in years until extension dates, as"
             << " increasing sequence" << endl;
         cout << "  of decimal numbers separated by spaces or commas: "
              << endl;
         for (j = 1; j <= mTX; j++)
             cin >> TX[j];
         if (TX[mTX] >= T) {
            cout << " All extension times must < maximum time to"
                 << " expiration!" << endl;
            goto label_4;
         }
    }


label_5:
    cout << " Enter strike price of option: " << endl;
    float X;
    cin >> X;
    if (X < 0.0) {
        cout << " Strike price cannot be negative!" << endl;
        goto label_5;
    }

    cout << endl;
    cout << " Enter data for riskless bonds and the underlying asset."
         << endl;
    cout << endl;
label_6:
    cout << " Enter price/$ maturity value of a riskless bond that"
         << "  matures when" << endl;
    cout << "  the option expires, as positive decimal number < 1.0: "
         << endl;
    float B0T;
    cin >> B0T;
    if (B0T <= 0.0 || B0T > 1.0) {
        cout << " Price of $1 future claim must be between 0. and 1.!"
             << endl;
        goto label_6;
    }

label_7:
    cout << " Enter initial price of the underlying asset: " << endl;
    float S0;
    cin >> S0;
    if (S0 < 0.0) {
        cout << " The price must be nonnegative!" << endl;
        goto label_7;
    }
label_8:
    cout << " Enter its annualized volatility (std. dev. of annual"
         << " return): " << endl;
    float sig;
    cin >> sig;
    if (sig < 0.0) {
        cout << " Volatility must be positive!" << endl;
        goto label_8;
    }

label_9:
     cout << " Enter \"stock\", \"index\", or \"futures\
           << " to identify the underlying asset: " << endl;
     cin >> underlying;
     if (strcmp(underlying,"stock") == 0) {
label_10:
         cout << " Enter number of dividends the stock pays during"
              << " life of option." << endl;
         cout << " If none, enter 0: " << endl;
         int ndiv;
         cin >> ndiv;
         if (ndiv > 0) {
            cout << " Do you want to model dividends as Proportional"
                 << "  tothe stock price, or" << endl;
            cout << "  as Fixed dollar amounts?  Enter 'p' or 'f': "
                 << endl;
            cin >> divtype;
            cout << " Enter successive times in years to ex dates as"
                 << " decimal numbers" << endl;
            cout << "  separated by spaces or commas: " << endl;
            for (j=1; j <= ndiv; j++)
                cin >> Tdiv[j];
            if (Tdiv[ndiv] > T) {
                cout << " Enter only ex-dividend times before option"
                     << " expires!" << endl;
                goto label_10;
            }
            if (divtype == 'p') {
               cout << "Enter the successive dividends as percentages"
                    << " of stock price," << endl;
               cout << " as decimal numbers separated by spaces or"
                    << " commas: " << endl;
               for (j=1; j <= ndiv; j++)
                   cin >> propdiv[j];
            } 
            else if (divtype == 'f') {
               cout << " Enter successive dividends in dollar terms"
                    << " as decimal numbers" << endl;
               cout << "  separated by spaces or commas: " << endl;
               for (j=1; j <= ndiv; j++)
                   cin >> fixeddiv[j];
            }
         } 
         else if (ndiv < 0) {
            cout << " Number of dividends must be nonnegative integer!"
                 << endl;
            goto label_10;
         }
         goto label_11;
      } 
     else if (strcmp(underlying,"index") == 0) {
         cout << " Enter a continuously-compounded, annualized dividend"
              << endl;
         cout << "  rate (in %), or 0: " << endl;
         cin >> divrate;
         goto label_11;
      }
//*     Underlying should be futures if reach here...
     if (strcmp(underlying,"futures") != 0) {
         cout << " Asset must be one of stock, index, or futures!"
              << endl;
         goto label_9;
     }

//*     Process some of the inputs...
label_11:
     if (mTX > 0) {
         for (j=1; j <= mTX; j++)
             nTX[j]=round(n*TX[j]/T);
     }
     if (ndiv > 0) {
         for (j=1; j <= ndiv; j++) 
         {
             nTdiv[j]=n*Tdiv[j]/T;
             if (divtype == 'p') 
                 propdiv[j]=propdiv[j]/100.0;
             if (divtype == 'f') 
                 fixeddiv[j]=fixeddiv[j]/X;
         }
     }
     divrate=divrate/100.0;

     float discount;

//*     Deal with trivial cases S0=0 and X=0...
     if (S0 == 0.0) {
         O[n]=X*intrinsic(option,S0);
         if (strcmp(type, "European") == 0) {
//*           discount the strike back from first exercise date...
             discount=B0T;
             if (mTX > 0) 
                 discount=pow(B0T,(TX[1]/T));
             O[n]=discount*O[n];
         }
         goto label_12;
     }
     if (X == 0.0) {
//*        this handles both puts and calls
         O[n]=S0*intrinsic(option, 2.0);
         if (strcmp(type, "European") == 0) {
//*           allow for dividends missed before exercise...
             if (strcmp(underlying,"stock") == 0 && ndiv > 0) {
                 float Tmax=max(T,TX[1]);
                 if (divtype == 'p') {
                     for (j=1; j <= ndiv; j++) 
                     {
                         if (Tdiv[j] < Tmax) 
                             O[n]=O[n]*(1.0-propdiv[j]);
                     }
                 } 
                 else if (divtype == 'f') {
                     float discounteddivs=0.0;
                     for (j=1; j <= ndiv; j++) 
                     {
                         if (Tdiv[j] < Tmax) 
                             discounteddivs=discounteddivs 
                            + fixeddiv[j]*pow(B0T,(Tdiv[j]/T));
                     }
                     O[n]=O[n]-discount;
                 }
             } 
             else if (strcmp(underlying,"index") == 0 && divrate > 0)
             {
                 if (mTX > 0) 
                     O[n]=O[n]*exp(-divrate*TX[1]);
                 else
                     O[n]=O[n]*exp(-divrate*T);
             }
         }
         goto label_12;
     }

//*     Scale stock price by strike, and define necessary parameters...
     float SX=S0/X;
     
     lnu=sig*sqrt(T/n);
     float Bn=pow(B0T,(1.0/n));
/*
*     nX is greatest integer in number upticks to put option at the money
*        Call is in the money for more upticks than nX; put for nX or fewer.
*/
     int nX= .5*( n-log(SX)/lnu );
     float u=exp(lnu);
/*     
*     Define discount-weighted risk-neutral probabilities.  Bpihat is
*        discounted uptick probability, which depends on the type of
*        underlying asset and the continuous dividend rate, if any.
*        Bpihatu (Bpihatd) are discounted probabilities of moves that
*        are favorable (unfavorable) to the specific type of option.
*        f is the 'favorable' proportional price change for underlying.
*      if (strcmp(underlying,"stock")==0 || 
*      strcmp(underlying,"futures") == 0) {
*/

     float Bpihat, Bpihatu, f;

     if (strcmp(underlying,"stock") == 0) 
         Bpihat=(u-Bn)/(u*u-1);
     else if (strcmp(underlying,"index") == 0) 
         Bpihat=(u*exp(-divrate*T/n)-Bn)/(u*u-1);
     else if (strcmp(underlying,"futures") == 0) 
         Bpihat=Bn/(u+1);
     
      if (strcmp(option,"call") == 0) {
          Bpihatu=Bpihat;
          f=u;
          nX=min(nX+1,n);
      } 
      else if (strcmp(option,"put") == 0) {
          Bpihatu=Bn-Bpihat;
          f=1.0/u;
          nX=max(n-nX,1);
      }
      float Bpihatd=Bn-Bpihatu;
      
/*
*     Initialize option values at the n-step from highest down to zero,
*        corresponding to first out-of-money price level...
*/
      float SXDiv;

      if (ndiv == 0) {
//*        Core values of shares with/without dividends are the same.
          SXDiv=SX;
      } 
      else if (ndiv > 0) {
/*
*        Figure core value of shares allowing for lump-sum dividends
*          during life of option...
*/
          if (divtype == 'p') {
//*           determine ex-dividend core of stock value at n-step...
              float divfactor=1.0;
              for (i=1; i <= ndiv; i++)
                  divfactor=divfactor*(1.0-propdiv[i]);
              SXDiv=SX*divfactor;
          } 
          else if (divtype == 'f') {
/*
*           determine ex-dividend core value of stock, which is the
*             initial price minus the time-0 present value of all
*             dividends to be paid during life of option.  This is
*             the part that will follow Bernoulli dynamics.
*/
              float totaldiv=0.0;
              for(i=1; i <= ndiv; i++)
                  totaldiv=totaldiv+fixeddiv[i]*pow(B0T,(Tdiv[i]/T));
              SXDiv=SX-totaldiv;
          }
      }
/*
*     Calculate stock value at highest node of n-step, { work down
*       the nodes and set terminal value of option...
*/
      float S=SXDiv*pow(f,n);

      for (j=n; j >= nX-1; j--) 
      {
          O[j]=intrinsic(option,S);
          S=S/(f*f);    //expanded square
      }
      if (printit == 'y') {
          for (j = nX-1; j <= n; j++)
              cout << X*O[j] << " ";
          cout << endl;

          // "pause" translated as "press any key to continue."
          char ignored;
          cin >> ignored;
      }

//*     Begin stepping backwards toward solution...
      for (step=n-1; step >= 0; step--) 
      {
//*       Calculate the most favorable possible stock price at this step.
          S=SXDiv*pow(f,step);
//*        Moving down the column of stock prices from best to worst,
//*           calculate the option value at each node...
          for (j=n;j >= max(nX,n-step); j--) 
          {
              float SCumDiv=S;
//*           Compute discounted r.n. expectation of next-period's values
//*              to get option's value if not exercised...
              O[j]=Bpihatu*O[j]+Bpihatd*O[j-1];
//*           Figure cum-dividend value of shares to calculate intrinsic
//*             value...
              if (ndiv > 0) {
                  if (divtype == 'f') {
//*                 add back in the present value of dividends not yet
//*                     paid...
                      for (id=1;id <= ndiv; id++) 
                      {
                          if (nTdiv[id] > step) 
                              SCumDiv=SCumDiv+fixeddiv[id]*
                              pow(B0T,((nTdiv[id]-step)/T));
                      }
                  } 
                  else if (divtype == 'p') {
//*                 factor back in all proportional dividends not yet
//*                     paid...
                      for (id=1; id <= ndiv; id++) 
                      {
                          if (nTdiv[id] > step) 
                              SCumDiv=SCumDiv/(1.0-propdiv[id]);
                      }
                  }
              }
              intrinsicvalue=intrinsic(option,SCumDiv);
//*           For American options decide whether to exercise here...
              if (strcmp(type,"American") == 0) 
                  O[j]=max(O[j],intrinsicvalue);
              
//*           For extendable options, determine whether exercise is
//*               required...
              for (int iTX=0; iTX <= mTX; iTX++) 
              {
                  if (step == nTX[iTX] && intrinsicvalue > 0)
                      O[j]=intrinsicvalue;
              }

              if (O[j] == intrinsicvalue && printit == 'y') {
                  cout << "Option exercised at step " << step << 
                      ", time " << step*T/n << ", stock price " <<
                       X*S << endl;
                  char ignored;
                  cin >> ignored;
              }
//*           Calculate stock price for next position in the array...
              S=S/(f*f);  //expanded square
              
          }
          
          if (printit == 'y') {
              for (j = nX-1; j <= n; j++)
                  cout << X*O[j] << endl;
              char ignored;
              cin >> ignored;
          }
      }
      
//*     Rescale option value by strike price and write the results...
      O[n]=O[n]*X;
      
label_12:
      for (i = 0; i < 15; i++)
          cout << endl;

      cout << "                   " 
           << "Data for underlying asset:" << endl
           << "                   " 
           << "Type:" << "                              " 
           << setw(8) << underlying << endl
           << "                   " 
           << "Initial price: " << "                   "
           << setw(7) << S0 << endl
           << "                   " 
           << "Volatility: " << "                   "
           << setw(7) << sig << endl;

      
      if (strcmp(underlying,"index") == 0) {
          cout << "                   " 
               << "Dividend rate (%):" << "                "
               << setw(7) << 100*divrate << endl;
      } 
      else if (strcmp(underlying,"stock") == 0) {
          if (ndiv == 0) {
              cout << "                   " << "Dividends: none"
                   << endl;
          } 
          else 
          {
              if (divtype == 'p') {
                  cout << "                   " 
                       << "Proportional dividend payments:" << endl;
                  for (id=1; id <= ndiv; id++) 
                  {
                      cout << "                                      "
                           << "Time:" << setw(7) << Tdiv[id]
                           << "       " << setw(5) << 100*propdiv[id]
                           << "%" << endl;
                  }
              } 
              else if (divtype == 'f') {
                  cout << "                    " 
                       << "Fixed dividend payments:" << endl;
                  for (id=1; id <= ndiv; id++) 
                  {
                      cout << "                                      "
                           << "Time:" << setw(7) << Tdiv[id]
                           << ",     $" << setw(5) << X*fixeddiv[id]
                           << endl;
                  }
              }
          }
      }

      cout << endl << "                    " 
           << "Data for bonds:" << endl
           << "                    " << "Average interest rate:" << "             " << setw(7) << (-log(B0T)/T) << endl
           << endl;
      
      cout << "                    " << "Data for option:" << endl
           << "                    " << "Type" << "                              " << setw(8) << type << endl
           << "                    " << "Strike price: " << "                     " << setw(7) << X << endl
           << "                    " << "Years to expiration: " << "              " << setw(7) << T << endl;

      if (mTX > 0) {
          cout << "                    " << "Time to extension dates: "
               << "          " << setw(7) << TX[1] << endl;
          for (j = 2; j <= mTX; j++)
              cout << "                                                       " << setw(7) << TX[j] << endl;
          cout << endl 
               << endl 
               << "                    " << "Value of extendable "
               << type << " " << option 
               << ":" << setw(8) << O[n] << endl;
      } 
      else 
      {
          cout << endl
               << "                    " << "Value of " << type 
               << " " << option 
               << ":" << "           " << setw(8) << O[n] << endl;
      }

      return;
}


float intrinsic(const char *option, float s) 
{
      if (strcmp(option,"call") == 0) {
          return max((float) s-1.0, (float) 0.0);
      } 
      else if (strcmp(option,"put") == 0) {
          return max((float) 1.0-s, (float) 0.0);
      } 
      else 
      {
         cout << " Option type incorrectly specified!" << endl;
      }
      exit(1);
}


