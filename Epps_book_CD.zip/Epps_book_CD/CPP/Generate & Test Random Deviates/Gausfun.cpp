#include <math.h>


float randfun(double &seed);


float gausfun(double &seed)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Generates pseudorandom standard normals by adaptation
*                of algorithm  NA (see Reference) with exponentials
*                generated via inverse probability transform.
*     Input:     seed, a double precision number greater than or equal
*                to unity.
*     Output:    A single pseudorandom normal deviate.
*     Reference: Fishman, G.S.(1996), Monte Carlo: Concepts, Algorithms,
*                and Applications, Springer: New York
*     Notes:     Uses RANDFUN to generate uniform deviates.
*                Example to generate vector of 1000 i.i.d. normals:
*                   int main() {
*                       const int N = 1000;
*                       float Z[N];
*                       double SEED = 1234.0;
*                       for (int i = 1; i <= N; i++)
*                           Z[i] = gausfun(SEED);
*                       return 0;
*                   }
*
*     Required routines:  RANDFUN
*----------------------------------------------------------------------
*/

    static int iflag = 1;
    static float y = 0.0;

//*     Cauchy parameters

    static float ac = .6380631366077803, bc = .5959486060529070;
    static float qc = .9339962957603656, wc = .2488702280083841;
    static float bigac = .6366197723675813, bigbc = .5972997593539963;
    static float hc = .0214949004570452, pc = 4.9125013953033204;
    
//*
    iflag = -iflag;
    float return_value = y;
    
    if (iflag > 0) 
        return return_value;
    
//*     Generate exponential variate, v, via inverse transform
    float v=-log(randfun(seed));
    float sg=v+v;
    
//*     Generate Cauchy variate, w, via Fishman's algorithm CA
    float t=randfun(seed)-.5;
    float sc=wc-t*t;
    float w;
    if(sc > 0.0) 
    {
        w=t*(bigac/sc+bigbc);
        goto label_2;
    }
    
label_1:
    t=randfun(seed)-.5;
    sc=.25-t*t;
    w=t*(ac/sc+bc);
    if( (sc*sc*((1.0+w*w)*(hc*randfun(seed)+pc)-qc)+sc) > 0.5) 
        goto label_1;

label_2:;
    return_value=sqrt(sg/(1.0+w*w));
    y=w*return_value;
    if(randfun(seed) < 0.5) 
        return_value=-return_value;
    return return_value;
}



