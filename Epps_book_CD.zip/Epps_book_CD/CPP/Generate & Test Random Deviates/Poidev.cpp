#include <math.h>

float randfun(double &seed);

void poidev(float theta, int n, int jv[], double &seed)
{
/*
*----------------------------------------------------------------------
*     Purpose:   Generates pseudorandom Poisson variates by inversion
*                of c.d.f.
*     Input:     Poisson parameter, theta
*                Number of variates generated, n
*                Double precision seed value >1, seed
*     Output:    n-array of Poisson deviates, jv
*     Notes:     (1) A uniform u is generated.  A table of F(j) is
*                    constructed out to j* = {first j: F(j) > u}, and
*                    j* is returned as the deviate.  For new values of
*                    u less than umax (the max of preceding u's) the
*                    corresponding j's are read from the table.  When
*                    u > umax is generated, the table is extended.
*                (2) Uses RANDFUN to generate uniform deviates.
*                    Replace as desired.
*     Required routines:  RANDFUN
*----------------------------------------------------------------------
*/
    float F[100+1],P[100+1];
    int jmax=0;
    float umax=exp(-theta);
    P[0]=umax;
    F[0]=umax;
    
//*     Initialize first values of c.d.f. and prob. mass function
    for (int i=1; i <= n; i++)
    {
        float u=randfun(seed);
        for (int j=0; j <= 100; j++)
        {
            if(u > umax && j > jmax) 
            {
//*     Desired value not yet in table, and we're at the point
//*       where we can add to the table of values of c.d.f.
                P[j]=P[j-1]*theta/j;   
                F[j]=F[j-1]+ P[j];
                
//*     In the Poisson case can compute P[j] sequentially from P[j-1]
                umax=F[j];
                jmax=j;
                
                if(F[j] >= u) 
                {
                    jv[i]=j;
                    goto label_2;
                }
                goto label_1;
            }
            else if (u > umax && j <= jmax) 
            {
//*           desired value not in table, but we haven't yet reached
//*           the point where we can add to it
                goto label_1;
            }
            else if (u <= umax) 
            {
//*              desired value is in the table
                if(F[j] >= u) 
                {
//*                 pick value from table
                    jv[i]=j;
                    goto label_2;
                }   
            }
label_1:
            ;
        }
label_2:        
        ;
    }
    return;
}



