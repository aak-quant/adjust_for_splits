#include <iostream.h>


float randfun(double &seed)
{
/*
*----------------------------------------------------------------------
*     Purpose:    Generate pseudorandom uniform (0,1) deviates.
*     Input:      Double precision number > 1, seed
*     Output:     One uniform deviate.
*     References: Fishman, G. (1996) Monte Carlo: Concepts, Algorithms,
*                    and Applications, Springer-Verlag: New York.
*     Notes:      Adapted to function subprogram from subroutine
*                    written by L.R. Moore, in Fishman (1996).
*     Required routines:  None
*----------------------------------------------------------------------
*/
    double dz,dover,dz1,dz2,dover1,dover2;
    
    static double dtwo31 = 2147483648.0, dmdls = 2147483647.0;
    static double da1 = 41160.0, da2 = 950665216.0;
    
    dz=seed;
    dz=long(dz);
    dz1=dz*da1;
    dz2=dz*da2;
    dover1=long(dz1/dtwo31);
    dover2=long(dz2/dtwo31);
    dz1=dz1-dover1*dtwo31;
    dz2=dz2-dover2*dtwo31;
    dz=dz1+dz2+dover1+dover2;
    dover=long(dz/dmdls);
    dz=dz-dover*dmdls;
    seed=dz;
    return dz/dmdls;
}



