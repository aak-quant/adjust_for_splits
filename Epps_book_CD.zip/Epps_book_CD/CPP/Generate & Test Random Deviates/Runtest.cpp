#include <math.h>

float runtest(float u[], int n, int &nrun)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Perform large-sample runs test for randomness.
*     Input:     n-array of observations, u
*                Number of observations, n
*     Output:    Runs test statistic, distributed as chi-square(1)
*                under null hypothesis of randomness.
*                Number of runs, nrun.
*     Reference: Wonnacott, T. and Wonnacott, R. (1977) Introductory
*                Statistics. Wiley: New York.
*     Notes:
*                    Significance level/ Critical points
*         .50      .25      .10      .05     .025     .010     .005
*        0.45     1.32     2.71     3.84     5.02     6.63     7.88
*     Required routines:  None
*----------------------------------------------------------------------
*/
    float rn=n;
    nrun=1;
    
    for (int j = 2; j <= n; j++)
    {
        if((u[j]-0.5)*(u[j-1]-0.5) < 0.0) 
            nrun=nrun+1;
    }
    
    return pow((4*pow((nrun-rn/2-1),2)/rn),2);
}


