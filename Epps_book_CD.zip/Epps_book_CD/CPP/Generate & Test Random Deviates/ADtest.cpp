#include <iostream.h>
#include <math.h>

double phi(float x);
void sort(int n, float y[]);


void ADtest(int n, float y[], float &ybar, float &sdy, float &ad)
{
/*    
*----------------------------------------------------------------------
*     Purpose:    Conducts modified Anderson-Darling test of normality
*                 on array y of length n.
*     Input:      y, array of length n
*                 ybar, sdy   = sample mean and variance (divisor n-1)
*                 If ybar,sdy = 0 on input, they will be computed
*     Output:     Anderson-Darling statistic, ad
*     Reference:  "Anderson-Darling test for goodness of fit",
*                 Encyclopedia of Statistical Sciences, v1, pp.81-85
*                 eq.(3) and a* modification for case 3, as specified
*                 in table 1.
*
*                   Significance level/critical points (all n)
*                 .100          .050          .025          .010
*                 .631          .752          .873         1.035
*
*     Notes:      Vector y is returned in increasing order
*                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*     Required routines:  PHI
*     From Numerical Recipes, Press et. al. (1992): SORT
*----------------------------------------------------------------------
*/
    int i;
    
    float rn=n;
    
    if(ybar != 0.0 && sdy > 0.0) 
        goto label_20;
    
    ybar=0.0;
    sdy=0.0;
    
    for (i=1; i <= n; i++)
        ybar=ybar+y[i];

    ybar=ybar/rn;
    
    for (i=1; i <= n; i++) 
        sdy=sdy+(y[i]-ybar)*(y[i]-ybar);   
    
    ybar=ybar/rn;
    sdy=sqrt(sdy/(rn-1.0));

label_20:
    sort(n,y);
    
    ad=0.0;
    
    for(i=1; i <= n; i++) 
    {
        float r2i1=2*i-1;
        float v1=phi((y[i]-ybar)/sdy);
        float v2=phi((ybar-y[n+1-i])/sdy);
/*        
*        v2 defined as negative deviation, v2 now replaces 1-v2 in the
*           Anderson-Darling formulas
*/
        if(v1 <= 0.0 || v2 <= 0.0) 
        {
            cout << "extreme value in computation of ad test  " << endl;
            cout << "i,y[i],y(n+1-i) standardized= " << i << " " 
                 << (y[i]-ybar)/sdy << " " << (y[n+1-i]-ybar)/sdy
                 << endl;
            cout << "v1,v2 " << v1 << " " << v2 << endl;

            if(v1<=0.0) 
                v1=pow(10.0, -30);  
            if(v2<=0.0) 
                v2=pow(10.0, -30);  
        }
        
        ad=ad+r2i1*(log(v1)+log(v2));
    }
    
    ad=(-rn-ad/rn)*(1.0+0.75/rn+2.25/(rn*rn));  
    return;
}


