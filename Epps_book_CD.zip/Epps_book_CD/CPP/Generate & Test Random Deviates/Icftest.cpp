#include <iostream.h>

#include <string.h>
#include <math.h>



void icftest(int n, float y[], float &cf)
{
/*    
*----------------------------------------------------------------------
*     Purpose:   Test of normality, mean and variance unspecified
*     Input:     Number of observations, n
*                Array of observations, y
*     Output:    Value of CF statistic, cf
*     Reference: Epps, T. & Pulley, L. (1983) Biometrika 70(3),723-726
*                Baringhaus,L. et al. (1989) Commun. in Statist.,
*                   Comp. & Simul., 18(1), 363-79
*     Notes:     Data array is returned in standard form.
*
*                          Percentage Points of CF
*                 n\1-p |   0.900   0.950   0.975   0.990
*                 ----------------------------------------------
*                  4    |   0.248   0.291   0.316   0.332
*                  5    |   0.243   0.323   0.388   0.445
*                  6    |   0.262   0.325   0.403   0.499
*                  8    |   0.269   0.344   0.424   0.523
*                 10    |   0.278   0.355   0.435   0.542
*                 15    |   0.284   0.364   0.446   0.560
*                 20    |   0.288   0.369   0.449   0.562
*                 30    |   0.289   0.370   0.456   0.564
*                 50    |   0.290   0.372   0.459   0.574
*
*     Required routines:  None
*----------------------------------------------------------------------
*/
    const char *prt="off";
    int i, j;

    float sy1=0.0;
    float sy2=0.0;
    for (i=1; i<= n; i++) 
    {
        sy1=sy1+y[i];
        sy2=sy2+y[i]*y[i];
    }
    sy1=sy1/n;                 
    sy2=sqrt(sy2/n-sy1*sy1);   
    
    if(sy2 == 0.0) 
    {
        cout << "CF Test aborted:  Sample has zero variance. " 
             << sy2 << endl;
        goto label_100;
    }

    for (i=1; i <= n; i++)
        y[i]=(y[i]-sy1)/sy2;
    
    if(strcmp(prt,"on") == 0)
        cout << sy1 << sy2 << endl;
    
    float sexp1=0.0;
    float sexp2=0.0;

    for (i=1; i <= n; i++) 
    {
        sexp1=sexp1+exp(-0.25*(y[i]*y[i]));   
        if(i == n) 
            goto label_50;
        
        for (j=i+1; j <= n; j++)
            sexp2=sexp2+exp(-0.5*((y[i]-y[j])*(y[i]-y[j])));  
            
label_50:
        ;
    }
    
    cf=1.0+float(n)/sqrt(3.0) + 2.0*sexp2/n - sqrt(2.0)*sexp1;  

    if(strcmp(prt,"on") == 0) 
        cout << sexp1 << sexp2 << cf << endl;

label_100:
    return;
}



