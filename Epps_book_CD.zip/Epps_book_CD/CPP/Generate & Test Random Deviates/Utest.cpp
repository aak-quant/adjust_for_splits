#include <iostream.h>

#include <math.h>
#include <stdlib.h>

float utest(int n, float u[])
{
/*
*----------------------------------------------------------------------
*     Purpose:   Test that data are i.i.d as uniform on (0,1)
*     Input:     n-array of numbers to be tested for uniformity, u
*                Number of observations, n
*     Output:    N2 test statistic for uniformity
*     Reference: D'Agostino, R. and Stephens, M. (1986) Goodness of Fit
*                Techniques, Dekker: New York, pp.351-354, 357.
*     Notes:     Statistic is distributed for large n approximately as
*                chi-square(2).
*                   Significance Level/Critical Points
*         .500     .250     .100     .050     .025     .010     .005
*        1.386    2.773    4.605    5.991    7.378    9.210   10.597
*     Required routines:  None
*----------------------------------------------------------------------
*/
    float v1=0.0;
    float v2=0.0;
    
    float rtn=sqrt(float(n)); 

    for (int j=1; j <= n; j++) 
    {
        if(u[j] < 0.0 || u[j] > 1.0) 
            goto label_1;
        float y=u[j]-0.5;
        v1=v1+y;
        v2=v2+y*y;
    }
    
    v1=2.0*sqrt(3.0)*v1/rtn;
    v2=sqrt(5.0)*(6.0*v2/rtn-rtn/2.0);
    
    return v1*v1+v2*v2;

label_1:
     cerr << "Utest aborted: Values tested must be on interval [0,1]."
          << endl;
     exit(1);
}



